/*
Copyright (c) 2010 - 2012 JackBe Corporation
Copyright (c) 2013 - 2017 Software AG, Darmstadt, Germany 
and/or Software AG USA Inc., Reston, VA, USA, and/or its
subsidiaries and/or its affiliates and/or their licensors.

Use, reproduction, transfer, publication or disclosure is
prohibited except as specifically provided for in your
License Agreement with Software AG.
*/
angular.module('helloWorldModule')
    
    .config(['dashboardProviderProvider', 
        function (dashboardProviderProvider) {
            dashboardProviderProvider.widget('helloWorld', {
                title: 'Hello World!',
                category: 'customWidget',
                toolTip : {
                    "de":"Hello World!",
                    "en":"Hello World!"
                },
                actions: ['editName',
                    'hLine',
                    'copy', 'paste', 'cut', 'delete',
                    'toTop', 'bringForward', 'sendBackward', 'toBack',
                    'hideHeader','hideBorder'],
                description: 'Hello World widget',
                templateUrl: 'widgets/customWidgets/helloWorld/partials/helloWorld.html',
                iconUrl: 'widgets/customWidgets/helloWorld/assets/images/menu_icon_32x32.png',
                controller: 'helloWorldCtrl',
                container: {
                    hideHeader: false,
                    hideBorder: false,
                    width: 200,
                    height: 150,
                    contentMinHeight: 60,
                    contentMinWidth: 60
                }
            });
    }]);
