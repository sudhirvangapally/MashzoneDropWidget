/*
Copyright (c) 2010 - 2012 JackBe Corporation
Copyright (c) 2013 - 2017 Software AG, Darmstadt, Germany 
and/or Software AG USA Inc., Reston, VA, USA, and/or its
subsidiaries and/or its affiliates and/or their licensors.

Use, reproduction, transfer, publication or disclosure is
prohibited except as specifically provided for in your
License Agreement with Software AG.
*/
/** Time pass
 * Every code that is part of the helloWorldWidget should be inside the hte helloWorld module.
 */
angular.module('helloWorldModule', ['prestoDashboard.dashboardProvider']);